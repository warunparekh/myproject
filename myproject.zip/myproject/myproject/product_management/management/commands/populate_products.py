# product_management/management/commands/populate_products.py
from django.core.management.base import BaseCommand
from shopping.models import Product

class Command(BaseCommand):
    help = 'Populate products'

    def handle(self, *args, **kwargs):
        # Create 50 products
        for i in range(1, 51):
            product = Product.objects.create(
                name=f'Product {i}',
                description=f'Description for product {i}',
                original_price = 200
                discount_data 
                
            )
            self.stdout.write(self.style.SUCCESS(f'Product {i} created'))
